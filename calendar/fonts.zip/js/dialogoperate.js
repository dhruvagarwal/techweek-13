$('#event1').hide();
alert('Press F11 for full experience !!');
$('#event2').hide();
$('#event3').hide();
$('#event4').hide();
$('#event5').hide();
$('#event6').hide();
$('#event7').hide();
$('#event8').hide();
$(function(){
	$('.calget').draggable({containment:$('.calget').parent().parent().parent()});
	$('.flash').draggable({containment:$('.flash').parent().parent().parent()});
	$('.dip').draggable({containment:$('.dip').parent().parent().parent()});
	$('.anim').draggable({containment:$('.anim').parent().parent().parent()});
	$('.prog').draggable({containment:$('.prog').parent().parent().parent()});
	$('.design').draggable({containment:$('.design').parent().parent().parent()});
	$('.robo').draggable({containment:$('.robo').parent().parent().parent()});
	$('.autocad').draggable({containment:$('.autocad').parent().parent().parent()});
	$('.webd').draggable({containment:$('.webd').parent().parent().parent()});
	
	var h = screen.height + 'px';alert(h);
	$("body").css("height",h);
	

});
   
  
$(document).ready(function(){
	$('.flash').dblclick(function(){
		$('#event1').show();
		$('#tung1').show();
		$('#event2').hide();
		$('#tung2').hide();
		$('#event3').hide();
		$('#tung3').hide();
		$('#event4').hide();
		$('#tung4').hide();
		$('#event5').hide();
		$('#tung5').hide();
		$('#event6').hide();
		$('#tung6').hide();
		$('#event7').hide();
		$('#tung7').hide();
		$('#event8').hide();
		$('#tung8').hide();
		$('#event1').draggable({containment:$('#event1').parent().parent()});

	});

	$('.flashmenu').click(function(){
		$('#event1').show();
		$('#tung1').show();
		$('#event2').hide();
		$('#tung2').hide();
		$('#event3').hide();
		$('#tung3').hide();
		$('#event4').hide();
		$('#tung4').hide();
		$('#event5').hide();
		$('#tung5').hide();
		$('#event6').hide();
		$('#tung6').hide();
		$('#event7').hide();
		$('#tung7').hide();
		$('#event8').hide();
		$('#tung8').hide();
		$('#event1').draggable({containment:$('#event1').parent().parent()});

	});

	$('.anim').dblclick(function(){
		$('#event1').hide();
		$('#tung1').hide();
		$('#event2').show();
		$('#tung2').show();
		$('#event3').hide();
		$('#tung3').hide();
		$('#event4').hide();
		$('#tung4').hide();
		$('#event5').hide();
		$('#tung5').hide();
		$('#event6').hide();
		$('#tung6').hide();
		$('#event7').hide();
		$('#tung7').hide();
		$('#event8').hide();
		$('#tung8').hide();
		$('#event2').draggable({containment:$('#event2').parent().parent()});
	});

	$('.animmenu').click(function(){
		$('#event1').hide();
		$('#tung1').hide();
		$('#event2').show();
		$('#tung2').show();
		$('#event3').hide();
		$('#tung3').hide();
		$('#event4').hide();
		$('#tung4').hide();
		$('#event5').hide();
		$('#tung5').hide();
		$('#event6').hide();
		$('#tung6').hide();
		$('#event7').hide();
		$('#tung7').hide();
		$('#event8').hide();
		$('#tung8').hide();
		$('#event2').draggable({containment:$('#event2').parent().parent()});
	});


	$('.prog').dblclick(function(){
		$('#event1').hide();
		$('#tung1').hide();
		$('#event2').hide();
		$('#tung2').hide();
		$('#event3').show();
		$('#tung3').show();
		$('#event4').hide();
		$('#tung4').hide();
		$('#event5').hide();
		$('#tung5').hide();
		$('#event6').hide();
		$('#tung6').hide();
		$('#event7').hide();
		$('#tung7').hide();
		$('#event8').hide();
		$('#tung8').hide();
		$('#event3').draggable({containment:$('#event3').parent().parent()});
	});

	$('.progmenu').click(function(){
		$('#event1').hide();
		$('#tung1').hide();
		$('#event2').hide();
		$('#tung2').hide();
		$('#event3').show();
		$('#tung3').show();
		$('#event4').hide();
		$('#tung4').hide();
		$('#event5').hide();
		$('#tung5').hide();
		$('#event6').hide();
		$('#tung6').hide();
		$('#event7').hide();
		$('#tung7').hide();
		$('#event8').hide();
		$('#tung8').hide();
		$('#event3').draggable({containment:$('#event3').parent().parent()});
	});


	$('.design').dblclick(function(){
		$('#event1').hide();
		$('#tung1').hide();
		$('#event2').hide();
		$('#tung2').hide();
		$('#event3').hide();
		$('#tung3').hide();
		$('#event4').show();
		$('#tung4').show();
		$('#event5').hide();
		$('#tung5').hide();
		$('#event6').hide();
		$('#tung6').hide();
		$('#event7').hide();
		$('#tung7').hide();
		$('#event8').hide();
		$('#tung8').hide();
		$('#event4').draggable({containment:$('#event4').parent().parent()});
	});

	$('.designmenu').click(function(){
		$('#event1').hide();
		$('#tung1').hide();
		$('#event2').hide();
		$('#tung2').hide();
		$('#event3').hide();
		$('#tung3').hide();
		$('#event4').show();
		$('#tung4').show();
		$('#event5').hide();
		$('#tung5').hide();
		$('#event6').hide();
		$('#tung6').hide();
		$('#event7').hide();
		$('#tung7').hide();
		$('#event8').hide();
		$('#tung8').hide();
		$('#event4').draggable({containment:$('#event4').parent().parent()});
	});

	$('.autocad').dblclick(function(){
		$('#event1').hide();
		$('#tung1').hide();
		$('#event2').hide();
		$('#tung2').hide();
		$('#event3').hide();
		$('#tung3').hide();
		$('#event4').hide();
		$('#tung4').hide();
		$('#event5').show();
		$('#tung5').show();
		$('#event6').hide();
		$('#tung6').hide();
		$('#event7').hide();
		$('#tung7').hide();
		$('#event8').hide();
		$('#tung8').hide();
		$('#event5').draggable({containment:$('#event5').parent().parent()});
	});

	$('.autocadmenu').click(function(){
		$('#event1').hide();
		$('#tung1').hide();
		$('#event2').hide();
		$('#tung2').hide();
		$('#event3').hide();
		$('#tung3').hide();
		$('#event4').hide();
		$('#tung4').hide();
		$('#event5').show();
		$('#tung5').show();
		$('#event6').hide();
		$('#tung6').hide();
		$('#event7').hide();
		$('#tung7').hide();
		$('#event8').hide();
		$('#tung8').hide();
		$('#event5').draggable({containment:$('#event5').parent().parent()});
	});

	$('.robo').dblclick(function(){
		$('#event1').hide();
		$('#tung1').hide();
		$('#event2').hide();
		$('#tung2').hide();
		$('#event3').hide();
		$('#tung3').hide();
		$('#event4').hide();
		$('#tung4').hide();
		$('#event5').hide();
		$('#tung5').hide();
		$('#event6').show();
		$('#tung6').show();
		$('#event7').hide();
		$('#tung7').hide();
		$('#event8').hide();
		$('#tung8').hide();
		$('#event6').draggable({containment:$('#event6').parent().parent()});
	});

	$('.robomenu').click(function(){
		$('#event1').hide();
		$('#tung1').hide();
		$('#event2').hide();
		$('#tung2').hide();
		$('#event3').hide();
		$('#tung3').hide();
		$('#event4').hide();
		$('#tung4').hide();
		$('#event5').hide();
		$('#tung5').hide();
		$('#event6').show();
		$('#tung6').show();
		$('#event7').hide();
		$('#tung7').hide();
		$('#event8').hide();
		$('#tung8').hide();
		$('#event6').draggable({containment:$('#event6').parent().parent()});
	});


	$('.dip').dblclick(function(){
		$('#event1').hide();
		$('#tung1').hide();
		$('#event2').hide();
		$('#tung2').hide();
		$('#event3').hide();
		$('#tung3').hide();
		$('#event4').hide();
		$('#tung4').hide();
		$('#event5').hide();
		$('#tung5').hide();
		$('#event6').hide();
		$('#tung6').hide();
		$('#event7').show();
		$('#tung7').show();
		$('#event8').hide();
		$('#tung8').hide();
		$('#event7').draggable({containment:$('#event7').parent().parent()});
	});

	$('.dipmenu').click(function(){
		$('#event1').hide();
		$('#tung1').hide();
		$('#event2').hide();
		$('#tung2').hide();
		$('#event3').hide();
		$('#tung3').hide();
		$('#event4').hide();
		$('#tung4').hide();
		$('#event5').hide();
		$('#tung5').hide();
		$('#event6').hide();
		$('#tung6').hide();
		$('#event7').show();
		$('#tung7').show();
		$('#event8').hide();
		$('#tung8').hide();
		$('#event7').draggable({containment:$('#event7').parent().parent()});
	});


	$('.webd').dblclick(function(){
		$('#event1').hide();
		$('#tung1').hide();
		$('#event2').hide();
		$('#tung2').hide();
		$('#event3').hide();
		$('#tung3').hide();
		$('#event4').hide();
		$('#tung4').hide();
		$('#event5').hide();
		$('#tung5').hide();
		$('#event6').hide();
		$('#tung6').hide();
		$('#event7').hide();
		$('#tung7').hide();
		$('#event8').show();
		$('#tung8').show();
		$('#event8').draggable({containment:$('#event8').parent().parent()});
	});

	$('.webdmenu').click(function(){
		$('#event1').hide();
		$('#tung1').hide();
		$('#event2').hide();
		$('#tung2').hide();
		$('#event3').hide();
		$('#tung3').hide();
		$('#event4').hide();
		$('#tung4').hide();
		$('#event5').hide();
		$('#tung5').hide();
		$('#event6').hide();
		$('#tung6').hide();
		$('#event7').hide();
		$('#tung7').hide();
		$('#event8').show();
		$('#tung8').show();
		$('#event8').draggable({containment:$('#event8').parent().parent()});
	});

	$("#tung1").click(function(){
                    					$("#event1").toggle().preventDefault();});

	$("#tung2").click(function(){
                    					$("#event2").toggle().preventDefault();});

	$("#tung3").click(function(){
                    					$("#event3").toggle().preventDefault();});

	$("#tung4").click(function(){
                    					$("#event4").toggle().preventDefault();});

	$("#tung5").click(function(){
                    					$("#event5").toggle().preventDefault();});

	$("#tung6").click(function(){
                    					$("#event6").toggle().preventDefault();});

	$("#tung7").click(function(){
                    					$("#event7").toggle().preventDefault();});

	$("#tung8").click(function(){
                    					$("#event8").toggle().preventDefault();});


                    
	
	                
				$("#login").hide();
				
	$(".opened.tunggal").hide();
	$("#turnoff").click(function () {
                $("#the_lights").css({'display' : 'block'});
                $("#the_lights").fadeTo("slow",1);
				$("#startbar").hide();
				$(".calget").hide();
				$(".window").hide();
		   	    $(".icons").hide();
  				   
                });
    $("#soft").click(function () {
                document.getElementById("the_lights").style.display="block";
                $("#the_lights").fadeTo("slow",0.8);
				$("#startbar").hide();
 			    $("#login").fadeIn();
				$(".calget").hide();
				$(".window").hide();
				$(".icons").hide();
                });
    $("#turnon").click(function () {
                document.getElementById("the_lights").style.display="block";
                $("#the_lights").fadeTo("slow",0);
	  			$("#startbar").fadeIn();
                $(".calget").fadeIn();
                $(".opened.tunggal").hide();
                $(".icons").fadeIn();
				$("#login").hide();
                });
                    
    $(".close").click(function(){
    			$(this).parent().parent().hide();
    			$(".opened.tunggal").hide();
				});
    
	$(".closep").click(function(){
    			$(this).parent().parent().hide();
    			$(".opened.tunggal").hide();
				$(this).parent().parent().show();
                });
    
	
    $(".min").click(function(){
      			$(this).parent().parent().hide();});

     $("#refresh").click(function(){
     	
     	location.reload(true);
     });
    $(document).click(function() {
        $('#rite').hide();
    });

    $(document).bind("contextmenu", function(e) {

    $('#rite').css({
        top: e.pageY+'px',
        left: e.pageX+'px'
    }).show();

    return false;

});
                   
    $(document).keyup(function(e) {

				if (e.keyCode == 27) { $('.window').hide(); }   // esc
				if (e.keyCode == 13) { 
		  					document.getElementById("the_lights").style.display="block";
		                    $("#the_lights").fadeTo("slow",0);
							$("#startbar").fadeIn();
                      		$(".calget").fadeIn();
                      		$(".opened.tunggal").hide();
                      		$(".icons").fadeIn();
						 	$("#login").hide(); 
						 	}   // enter
						});


});

